--(-Jake)
Powerup = Class{}

function Powerup:init(x,y,skin)
    -- simple positional and dimensional variables
    self.width = 16
    self.height = 16

    -- these variables are for keeping track of our velocity on the y-axis of the powerup
    self.dy = 40
    self.y = y
    self.x = x
    self.skin = skin
    -- this will effectively be the color of our ball, and we will index
    -- our table of Quads relating to the global block texture using this
end

function Powerup:spawn(x,y,skin)
    self.x = x
    self.y = y
    --randomizes the powerup
    self.skin = skin
    gPowergive = self.skin
    gPowerupfalling = true
end

function Powerup:collides(target) 

    if self.x > target.x + target.width or target.x > self.x + self.width then
        return false
    end

    if self.y > target.y + target.height or target.y > self.y + self.height then
        return false
    end

    return true
end

function Powerup:update(dt)
    self.y = self.y + self.dy * dt
    if self.y > VIRTUAL_HEIGHT then
        gPowerupdrop = false
        gPowerupfalling = false
    end
end

function Powerup:render()
    -- gTexture is our global texture for all blocks
    love.graphics.draw(gTextures['main'], gFrames['powerups'][self.skin],
        self.x, self.y)
end
